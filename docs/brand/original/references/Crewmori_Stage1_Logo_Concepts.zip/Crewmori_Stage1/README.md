# Crewmori — Stage 1 logo exploration

16 October 2026. Five concepts for selection; none is approved for release.
Stage 2 refinement, brand rules and the complete guideline have not started.

## Product grounding

Crewmori is a freelancer-owned AI business team. Scout, Promoter, Sales,
Account Manager, Operations and Finance handle business functions. The
freelancer performs the commissioned professional work and retains direction
and consequential approval controls. Coworkers are visible original
illustrations; tasks, handoffs and useful outputs form the working experience.

Sources inspected: the uploaded AI Business Team Complete Handoff archive,
especially 00_START_HERE.md, 01_PRD.md, 06_DESIGN_AND_INTERACTIONS.md and the
historical Stitch DESIGN.md. The user's current brief overrides the earlier
Manrope display direction: warm editorial serif display, ivory, forest green,
restrained pastels, readable sans-serif UI. No implementation work was done.

The 14-page uploaded Brand Guideline 2026 PDF was text-read and visually
inspected in full, with enlarged inspection of logo construction, clear space,
incorrect usage, color/layout and partner-placement examples. Its practical
diagrams, consistent labels and horizontal/square/vertical examples establish
a depth/presentation reference for the eventual guide. No Aladin logo,
religious symbolism, color rationale or layout rule has been transferred to
Crewmori. No meaning or etymology is invented for the name.

## Start here

Open `crewmori-five-concepts-comparison.png`, then the five `*-presentation.png`
sheets. All use the same surfaces, type, forest green and presentation scale.
Symbol sizes are normalized by apparent area with a maximum bounding size.
The comparison contains no mockups or recommendation badges.

Each numbered folder contains:

- `*-primary.svg` and `*-primary.png`: proposed horizontal primary logo.
- `*-black.svg/png` and `*-white.svg/png`: monochrome and reversed logos.
- `*-symbol-primary.svg/png`, `*-symbol-black.svg/png`, `*-symbol-white.svg/png`.
- Transparent green and white symbol PNGs at exact 16, 24 and 32 pixel sizes.

Primary transparent PNGs are 2028 x 480 px. Symbol previews are 512 x 512 px.
Presentations are 1800 x 1260 px; comparison is 2100 x 1360 px. The native-size
examples are embedded at one source-image pixel per sheet pixel; a chat or
image viewer may scale the whole sheet. Separate tiny PNGs are authoritative.

## The five directions

### 01 — Open Crew

**Construction:** A substantial open C, round at its back, with a long angled
upper terminal and a shorter squared lower return.

**Immediate:** A recognizable C. **Secondary:** space held open for an
independent owner; an accessible supporting structure. The two unequal
terminals add direction without an arrow.

**Fit/application:** A quiet parent identity beside expressive coworkers;
particularly effective in a sidebar, favicon or proposal header.

**Tradeoff:** Its relevance to teamwork is interpretive. An initial-based mark
is familiar territory, so the unequal terminals and proportions matter.

### 02 — Working Seam

**Construction:** Two broad bent bands with opposite rounded resting ends and
open diagonal ends. A continuous negative-space passage keeps them distinct.

**Immediate:** Two complementary contributions exchanging direction.
**Secondary:** coordinated handoffs and continuity between specialists. It
does not claim the owner is literally encoded in the mark.

**Fit/application:** Closest to the product's actual working relationships;
especially strong for the main app identity and Team Overview header.

**Tradeoff:** It can evoke exchange/synchronization or a link. Its diagonal
geometry feels more mechanical than the open C. The tightest exploratory
gaps were widened before final small-size exports.

### 03 — Shared Bearing

**Construction:** Two unequal forward-facing planes, aligned on the left and
separated by a substantial open seam. Rounded tips temper the direction.

**Immediate:** Shared forward movement. **Secondary:** distinct capabilities
contributing under one bearing toward useful outcomes.

**Fit/application:** A more energetic option for an app icon or compact header.

**Tradeoff:** It can resemble a paper plane, open book or delivery mark. Owner
control is not visibly represented and is not claimed as a hidden meaning.

### 04 — Common Room

**Construction:** A broad continuous arch around a separate upright core,
with two generous open channels and no literal human head.

**Immediate:** A supporting enclosure with an independent center.
**Secondary:** belonging and room for the owner's own work.

**Fit/application:** The warmest territory for the illustrated team environment;
particularly suited to a Team Overview identity or welcoming app header.

**Tradeoff:** Architectural, doorway and institutional associations. The symbol
feels supportive and steady more readily than active or progressive.

### 05 — Folded Monogram

**Construction:** A broad M-like folded structure; its rounded left side and
short lower return introduce a secondary C-like reading.

**Immediate:** A compact M. **Secondary:** a C in the return and one continuous
fold joining separate contributions. The secondary letter is a discovery,
not a requirement for recognition.

**Fit/application:** A strong monogram for app avatars, proposal covers and
small professional signatures.

**Tradeoff:** Denser and more assertive than the other marks. At 16 px the M
survives while the secondary C reading becomes weak. It is less companionable.

## Comparative assessment

These are studio assessments, not customer-study results. Distinctiveness is
relative visual character, not trademark clearance. Small-size comments come
from the actual exported symbols; the remaining audience attributes are
hypotheses informed by the simulated panel.

| Concept | Distinctiveness | Small-size clarity | Product relevance | Professional credibility | Warmth | Illustrated interface fit |
|---|---|---|---|---|---|---|
| Open Crew | Moderate | Excellent | Good | High | High | Excellent |
| Working Seam | High | Good; diagonal ends soften | Very high | High | Medium | Excellent |
| Shared Bearing | Moderate | Good; tapered tips soften | Good | Good | Medium | Good |
| Common Room | Moderate | Good; center stays separate | High | High | High | Excellent |
| Folded Monogram | High | Good as M; C weak at 16 px | Moderate | High | Medium-low | Good |

**Recommendation: Working Seam.** It puts coordination into the geometry
without illustrating six departments or becoming a seventh mascot. It is the
most product-specific direction in this set. Its separation survives the tiny
exports; the main strategic concern is exchange/link familiarity.

**Runner-up: Open Crew.** It has the clearest initial recognition, the simplest
small-size behavior and a calmer business-document presence. Choose it if a
quiet, flexible parent brand matters more than visible collaboration symbolism.

## Typography and licensing

The exploration wordmark is **DejaVu Serif Bold, version 2.37**, with deliberate
pair spacing. It is shared across concepts to avoid confusing symbol selection
with five unrelated font choices. No glyph outlines were altered.

DejaVu uses the **Bitstream Vera Fonts License**; DejaVu changes are in the
public domain. The complete font notice is in `source/fonts/LICENSE-DejaVu.txt`.
The licensed font files used by the reproduction script are included. Sheet
labels use DejaVu Sans; sheet display names use DejaVu Serif.

Every logo SVG contains outlined wordmark paths: there is **no runtime font
dependency**. No image, script, filter, remote font or other remote resource is
embedded. Brand marks are authored vector geometry, not generated raster art.

## Reproduction and verification

`source/build_concepts.py` constructs the SVGs and rasterizes them through
PyMuPDF. Transparent PNGs come directly from that vector artwork. Presentation
PNGs compose the same SVG-rendered artwork, without repainting the symbols.
The script uses Pillow, fontTools, NumPy and PyMuPDF; `source/requirements.txt`
records the versions used.

`source/concept-geometry.json` retains paths, transforms and optical bounds.
`source/crewmori-wordmark-outlined.svg` is the shared editable wordmark geometry.
`source/validation.json` records SVG checks and hashes. `QA.md` records the
visual review and practical limitations. This is a selection package, not the
final brand guideline, release assets or a claim of worldwide uniqueness.

## Next decision

Choose 01, 02, 03, 04 or 05, or name particular elements to explore together.
Nothing will be automatically merged. Stage 2 begins only after selection.
