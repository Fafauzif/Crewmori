"""Crewmori Stage 1. Original filled-path marks; font outlines; SVG-derived PNGs.

Run: python3 source/build_concepts.py
Requires: Python 3, PyMuPDF, fontTools, Pillow. Fonts and license are bundled.
No image generation, remote assets, browser screenshots, or external fonts.
"""
from pathlib import Path
import json, math, shutil, hashlib
import xml.etree.ElementTree as ET
from io import BytesIO
import fitz
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from fontTools.pens.boundsPen import BoundsPen
from fontTools.svgLib.path import parse_path

ROOT=Path(__file__).resolve().parents[1]
GREEN='#245C47'; IVORY='#F5F3EC'; PAPER='#FFFEFA'; INK='#202A25'; MUTED='#566159'; LINE='#D9DED3'
FONT_DIR=ROOT/'source'/'fonts'
FONT_DIR.mkdir(parents=True,exist_ok=True)
for name in ['DejaVuSerif-Bold.ttf','DejaVuSerif.ttf','DejaVuSans.ttf','DejaVuSans-Bold.ttf']:
    target=FONT_DIR/name
    if not target.exists(): shutil.copy('/usr/share/fonts/truetype/dejavu/'+name,target)
LICENSE=FONT_DIR/'LICENSE-DejaVu.txt'
if not LICENSE.exists():
    f=TTFont(FONT_DIR/'DejaVuSerif-Bold.ttf')
    LICENSE.write_text(f['name'].getDebugName(13)+'\n',encoding='utf-8')

CONCEPTS=[
 dict(id='01',name='Open Crew',slug='open-crew',idea='A C that holds space and stays open.',
      d='M88 14H45C21 14 8 27 8 50S21 86 45 86H75V65H45C34 65 29 61 29 50S34 35 45 35H69Z'),
 dict(id='02',name='Working Seam',slug='working-seam',idea='Two contributions. One continuous handoff.',
      d='M12 12H54Q60 12 64 16L88 40L72 56L50 34H12Q8 34 8 30V16Q8 12 12 12ZM88 88H46Q40 88 36 84L12 60L28 44L50 66H88Q92 66 92 70V84Q92 88 88 88Z'),
 dict(id='03',name='Shared Bearing',slug='shared-bearing',idea='Distinct roles moving in a shared direction.',
      d='M14 18L52 9Q56 7 60 9L86 20Q91 22 86 25L54 44H9V24Q9 19 14 18ZM9 56V78Q9 84 15 82L87 55Q93 52 87 49L77 44L58 56Z'),
 dict(id='04',name='Common Room',slug='common-room',idea='A capable structure around independent work.',
      d='M8 86V49C8 23 23 10 50 10S92 23 92 49V86H72V50C72 36 65 30 50 30S28 36 28 50V86ZM42 54H58V86H42Z'),
 dict(id='05',name='Folded Monogram',slug='folded-monogram',idea='A compact M with a C in its returning edge.',
      d='M10 18Q10 10 18 10H43L60 33L78 10H90V90H70V48L58 64L32 29V70H48V90H26Q10 90 10 74Z')
]

def svg_doc(body,w=100,h=100,title='Crewmori logo exploration',desc='Original vector geometry. Stage 1, not approved for release.'):
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}" role="img" aria-labelledby="title desc"><title id="title">{title}</title><desc id="desc">{desc}</desc>{body}</svg>'

def raster(svg,width,height=None):
    doc=fitz.open(stream=svg.encode('utf-8'),filetype='svg')
    page=doc[0]
    s=width/page.rect.width
    pix=page.get_pixmap(matrix=fitz.Matrix(s,s),alpha=True)
    # MuPDF pixmaps use premultiplied RGB; PNG encoding restores straight alpha.
    im=Image.open(BytesIO(pix.tobytes('png'))).convert('RGBA')
    if height and im.height!=height: raise ValueError((im.size,(width,height)))
    doc.close()
    return im

def bounds(d):
    p=BoundsPen(None);parse_path(d,p);return p.bounds

# Normalize apparent size by silhouette area, capped by a shared outer box.
for c in CONCEPTS:
    b=bounds(c['d']);w=b[2]-b[0];h=b[3]-b[1]
    im=raster(svg_doc(f'<path d="{c["d"]}"/>'),1000)
    area=np.asarray(im)[:,:,3].sum()/255/100
    scale=min(90/max(w,h),math.sqrt(3850/area))
    tx=50-scale*(b[0]+b[2])/2;ty=50-scale*(b[1]+b[3])/2
    c['transform']=f'translate({tx:.6f} {ty:.6f}) scale({scale:.6f})'
    c['native_bounds']=[tx+scale*b[0],ty+scale*b[1],tx+scale*b[2],ty+scale*b[3]]

def symbol(c,color=GREEN):
    return f'<path fill="{color}" transform="{c["transform"]}" d="{c["d"]}"/>'

f=TTFont(FONT_DIR/'DejaVuSerif-Bold.ttf');gs=f.getGlyphSet();cmap=f.getBestCmap()
cursor=0;wordpen=SVGPathPen(gs)
pair_adjust={'Cr':-22,'re':-25,'ew':-40,'wm':-36,'mo':-22,'or':-10,'ri':-30}
word='Crewmori'
for i,ch in enumerate(word):
    if i: cursor+=pair_adjust.get(word[i-1]+ch,0)
    g=cmap[ord(ch)];gs[g].draw(TransformPen(wordpen,(1,0,0,1,cursor,0)))
    cursor+=f['hmtx'][g][0]-12
WORD_D=wordpen.getCommands();WB=bounds(WORD_D)

def wordmark(color=GREEN,width=456):
    s=width/(WB[2]-WB[0]);h=(WB[3]-WB[1])*s
    return f'<path fill="{color}" transform="translate({-WB[0]*s:.6f} {WB[3]*s:.6f}) scale({s:.8f} {-s:.8f})" d="{WORD_D}"/>',h

def primary_svg(c,color=GREEN):
    wm,wh=wordmark(color)
    body=f'<g transform="translate(22 14) scale(1.32)">{symbol(c,color)}</g><g transform="translate(189 {(160-wh)/2+2:.6f})">{wm}</g>'
    return svg_doc(body,676,160,'Crewmori / '+c['name'], 'Stage 1 proposed primary logo. Symbol and DejaVu Serif Bold wordmark are fully outlined. No font dependency.')

def logo_img(c,width,color=GREEN): return raster(primary_svg(c,color),width)
def sym_img(c,size,color=GREEN):return raster(svg_doc(symbol(c,color)),size,size)

def font(size,kind='sans'):
    n={'sans':'DejaVuSans.ttf','bold':'DejaVuSans-Bold.ttf','serif':'DejaVuSerif.ttf','serifbold':'DejaVuSerif-Bold.ttf'}[kind]
    return ImageFont.truetype(str(FONT_DIR/n),size)
def text(im,xy,s,size=24,fill=INK,kind='sans',anchor=None):
    ImageDraw.Draw(im).text(xy,s,font=font(size,kind),fill=fill,anchor=anchor)
def place(im,layer,xy): im.paste(layer,tuple(map(round,xy)),layer)
def centered(im,layer,box):
    x,y,w,h=box;place(im,layer,(x+(w-layer.width)/2,y+(h-layer.height)/2))
def line(im,xy,fill=LINE,width=1):ImageDraw.Draw(im).line(xy,fill=fill,width=width)

for c in CONCEPTS:
    out=ROOT/(c['id']+'-'+c['slug']);out.mkdir(exist_ok=True)
    base='crewmori-'+c['id']+'-'+c['slug'];c['base']=base;c['folder']=out.name
    for label,color in [('primary',GREEN),('black','#000000'),('white','#FFFFFF')]:
        svg=primary_svg(c,color);(out/f'{base}-{label}.svg').write_text(svg)
        raster(svg,2028).save(out/f'{base}-{label}.png')
        ss=svg_doc(symbol(c,color),100,100,'Crewmori / '+c['name']+' / symbol')
        (out/f'{base}-symbol-{label}.svg').write_text(ss)
        raster(ss,512).save(out/f'{base}-symbol-{label}.png')
    for n in [16,24,32]:
        for label,color in [('green',GREEN),('white','#FFFFFF')]:
            sym_img(c,n,color).save(out/f'{base}-symbol-{n}-{label}.png')

    # Presentation sheets intentionally share dimensions, typography, surfaces,
    # optical normalization, section positions and background colors.
    sheet=Image.new('RGB',(1800,1260),IVORY);draw=ImageDraw.Draw(sheet)
    text(sheet,(64,43),'CREWMORI  /  IDENTITY EXPLORATION',19,MUTED,'bold')
    text(sheet,(1736,43),'STAGE 1  /  '+c['id'],19,MUTED,'bold',anchor='ra')
    text(sheet,(64,85),c['name'],63,INK,'serif')
    text(sheet,(66,171),c['idea'],24,MUTED)
    line(sheet,(64,229,1736,229))
    draw.rectangle((64,262,810,718),fill=PAPER)
    draw.rectangle((838,262,1736,718),fill=PAPER)
    text(sheet,(90,283),'01  SYMBOL',17,MUTED,'bold')
    text(sheet,(864,283),'02  PRIMARY LOCKUP',17,MUTED,'bold')
    centered(sheet,sym_img(c,350),(64,323,746,350))
    centered(sheet,logo_img(c,770),(864,353,846,278))
    # Monochrome/reverse lockups use the exact same SVG geometry.
    draw.rectangle((64,746,866,956),fill='#FFFFFF')
    draw.rectangle((894,746,1736,956),fill=GREEN)
    text(sheet,(90,769),'03  BLACK MONOCHROME',17,MUTED,'bold')
    text(sheet,(920,769),'04  REVERSED WHITE',17,'#FFFFFF','bold')
    centered(sheet,logo_img(c,635,'#000000'),(90,804,750,127))
    centered(sheet,logo_img(c,635,'#FFFFFF'),(920,804,790,127))
    text(sheet,(66,994),'05  SMALL-SIZE SYMBOLS',17,MUTED,'bold')
    text(sheet,(66,1022),'Actual pixel sizes',16,MUTED)
    text(sheet,(870,994),'4x inspection',17,MUTED,'bold')
    for i,n in enumerate([16,24,32]):
        x=104+i*170
        centered(sheet,sym_img(c,n),(x,1060,56,42))
        text(sheet,(x+28,1120),f'{n} px',17,MUTED,anchor='ma')
        # White reverse examples at native resolution on a constant dark tile.
        draw.rectangle((x-2,1158,x+58,1210),fill=GREEN)
        centered(sheet,sym_img(c,n,'#FFFFFF'),(x,1162,56,42))
        xx=878+i*225
        tiny=sym_img(c,n)
        enlarged=tiny.resize((n*4,n*4),Image.Resampling.NEAREST)
        centered(sheet,enlarged,(xx,1050,145,138))
        text(sheet,(xx+72,1203),f'{n} px / 4x',15,MUTED,anchor='ma')
    line(sheet,(724,990,724,1210))
    sheet.save(ROOT/f'{base}-presentation.png')

# Comparison: all cells equal, one color, no product mockups or endorsement badges.
board=Image.new('RGB',(2100,1360),IVORY);draw=ImageDraw.Draw(board)
text(board,(70,40),'CREWMORI  /  FIVE LOGO DIRECTIONS',23,MUTED,'bold')
text(board,(70,88),'One business. A team behind it.',65,INK,'serif')
text(board,(72,185),'Same color. Same wordmark. Comparable optical weight. Choose the idea first.',25,MUTED)
positions=[(66,266),(742,266),(1418,266),(404,796),(1080,796)]
for c,(x,y) in zip(CONCEPTS,positions):
    draw.rectangle((x,y,x+616,y+476),fill=PAPER)
    text(board,(x+28,y+22),c['id']+'  /  '+c['name'],25,INK,'bold')
    centered(board,sym_img(c,224),(x+24,y+67,568,247))
    centered(board,logo_img(c,490),(x+24,y+326,568,116))
text(board,(70,1315),'CONCEPTS FOR SELECTION  /  NOT A FINAL IDENTITY SYSTEM',18,MUTED)
text(board,(2030,1315),'16 OCT 2026',18,MUTED,anchor='ra')
board.save(ROOT/'crewmori-five-concepts-comparison.png')

# Wordmark source is shared for fair comparison, fully outlined.
wm,h=wordmark(width=1000)
(ROOT/'source'/'crewmori-wordmark-outlined.svg').write_text(svg_doc(f'<g transform="translate(20 20)">{wm}</g>',1040,math.ceil(h+40),'Crewmori / common exploration wordmark'))
(ROOT/'source'/'concept-geometry.json').write_text(json.dumps(CONCEPTS,indent=2))

# Internal native-size review strips, including all SVG masters rendered above.
review=Image.new('RGB',(1600,1040),IVORY);draw=ImageDraw.Draw(review)
for i,c in enumerate(CONCEPTS):
    y=i*200
    text(review,(20,y+10),c['id']+' '+c['name'],20,INK,'bold')
    centered(review,sym_img(c,130),(10,y+44,200,145))
    centered(review,logo_img(c,680),(220,y+42,700,153))
    for j,n in enumerate([16,24,32]):
        xx=980+j*180
        tiny=sym_img(c,n)
        centered(review,tiny,(xx,y+10,120,45))
        zoom=tiny.resize((n*3,n*3),Image.Resampling.NEAREST)
        centered(review,zoom,(xx,y+60,120,110))
        text(review,(xx+60,y+174),str(n)+' px',16,MUTED,anchor='ma')
review.save(ROOT/'source'/'qa-review.png')

# Automated geometry/transparency/package checks. Complements visual review.
records=[]
for p in sorted(ROOT.rglob('*.svg')):
    tree=ET.fromstring(p.read_text());tags=[e.tag.split('}')[-1] for e in tree.iter()]
    assert tree.attrib.get('viewBox'),p
    assert not set(tags)&{'image','script','foreignObject','filter','text'},p
    assert 'http' not in p.read_text().replace('http://www.w3.org/2000/svg',''),p
    im=raster(p.read_text(),700);a=np.asarray(im)[:,:,3]
    assert a.max()==255 and a.min()==0,p
    box=im.getbbox();assert box and box[0]>0 and box[1]>=0 and box[2]<im.width,p
    records.append({'file':str(p.relative_to(ROOT)),'viewBox':tree.attrib['viewBox'],'bbox_at_700w':box,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
for p in ROOT.rglob('*.png'):
    im=Image.open(p);im.verify()
    if 'presentation' not in p.name and 'comparison' not in p.name and 'qa-review' not in p.name:
        im=Image.open(p);assert im.mode=='RGBA',p
        a=np.asarray(im)[:,:,3];assert a.min()==0 and a.max()==255,p
audit={'renderer':'PyMuPDF '+fitz.VersionBind,'fonts':'DejaVu Serif Bold 2.37; paths in logo SVGs; bundled font license',
       'svg_count':len(records),'svg_checks':records,'small_png_sizes':[16,24,32],
       'claims':'Local construction and rendering checks only. No trademark clearance or customer validation.'}
(ROOT/'source'/'validation.json').write_text(json.dumps(audit,indent=2))
print(json.dumps({'concepts':len(CONCEPTS),'svgs':len(records),'pngs':len(list(ROOT.rglob('*.png'))),'output':str(ROOT)},indent=2))
